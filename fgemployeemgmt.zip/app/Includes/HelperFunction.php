<?php
function prd($data) {
    echo "<pre>";
    print_r($data);
    echo "</pre>"; die;
}

function pr($data) {
    echo "<pre>";
    print_r($data);
    echo "</pre>";
}